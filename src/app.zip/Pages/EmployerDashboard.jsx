import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { getJobsByEmployer } from "../Services/database";

const EmployerDashboard = () => {
  const [jobs, setJobs] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {

    const employerid = Number(
      localStorage.getItem("employerid")
    );

    if (!employerid) {
      navigate("/employer/login");
      return;
    }

    setJobs(getJobsByEmployer(employerid));

  });

  return (
    <section className="container mx-auto py-10">

      <h1 className="text-4xl font-bold mb-8">
        Employer Dashboard
      </h1>

      <button
        onClick={() => navigate("/add-job")}
        className="bg-indigo-600 text-white px-6 py-3 rounded-lg"
      >
        + Add New Job
      </button>

      <div className="mt-10 bg-white rounded-xl shadow p-6">

        <h2 className="text-2xl font-bold mb-5">
          My Posted Jobs
        </h2>

        {jobs.length === 0 ? (

          <p>No jobs posted yet.</p>

        ) : (

          jobs.map((job) => (

            <div
              key={job.id}
              className="border rounded-lg p-4 mb-4"
            >

              <h3 className="text-xl font-bold">
                {job.title}
              </h3>

              <p>{job.type}</p>

              <p>{job.location}</p>

              <p>{job.salary}</p>

              <Link
                to={`/jobs/${job.id}`}
                className="text-indigo-600"
              >
                View Job
              </Link>

            </div>

          ))

        )}

      </div>

    </section>
  );
};

export default EmployerDashboard;