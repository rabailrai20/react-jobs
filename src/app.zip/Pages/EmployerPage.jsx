import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginEmployer } from "../Services/database";

const EmployerLogin = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    const employer = loginEmployer(email, password);

    if (!employer) {
      alert("Invalid Email or Password");
      return;
    }

    // Save logged-in employer
    localStorage.setItem("employerid", employer.employerid);

    alert("Login Successful!");

    navigate("/employer/dashboard");
  };

  return (
    <section className="max-w-md mx-auto mt-16 bg-white shadow-lg rounded-xl p-8">
      <h1 className="text-3xl font-bold text-center mb-6">
        Employer Login
      </h1>

      <form onSubmit={handleLogin} className="space-y-5">

        <div>
          <label className="block mb-2 font-semibold">
            Email
          </label>

          <input
            type="email"
            placeholder="Enter Email"
            className="w-full border rounded-lg p-3"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block mb-2 font-semibold">
            Password
          </label>

          <input
            type="password"
            placeholder="Enter Password"
            className="w-full border rounded-lg p-3"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 text-white rounded-lg py-3 hover:bg-indigo-700"
        >
          Login
        </button>

      </form>
    </section>
  );
};

export default EmployerLogin;