import initSqlJs from "sql.js";
import jobs from "../jobs.json";

let db;

export async function initializeDatabase() {
  const SQL = await initSqlJs({
    locateFile: () => "/sql-wasm.wasm",
  });

  db = new SQL.Database();

  db.run(`
    CREATE TABLE IF NOT EXISTS employers (
      employerid INTEGER PRIMARY KEY,
      emailid TEXT UNIQUE,
      password TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS jobs (
      id INTEGER PRIMARY KEY,
      title TEXT,
      type TEXT,
      description TEXT,
      location TEXT,
      salary TEXT,
      employerid INTEGER,
      FOREIGN KEY(employerid) REFERENCES employers(employerid)
    );

    CREATE TABLE IF NOT EXISTS applications (
      applicationid INTEGER PRIMARY KEY,
      jobid INTEGER,
      name TEXT,
      email TEXT,
      resumeLink TEXT,
      FOREIGN KEY(jobid) REFERENCES jobs(id)
    );
  `);

  // =========================
  // DEFAULT EMPLOYERS
  // =========================

  const employerCount = db.exec("SELECT COUNT(*) FROM employers");

  if (employerCount[0].values[0][0] === 0) {
    db.run(`
      INSERT INTO employers (employerid,emailid,password)
      VALUES
      (1,'admin@gmail.com','1234'),
      (2,'hr@gmail.com','5678');
    `);
  }

  // =========================
  // DEFAULT JOBS
  // =========================

  const count = db.exec("SELECT COUNT(*) FROM jobs");

  if (count[0].values[0][0] === 0) {
    jobs.Jobs.forEach((job) => {
      db.run(
        `
        INSERT INTO jobs
        (
          id,
          title,
          type,
          description,
          location,
          salary,
          employerid
        )
        VALUES(?,?,?,?,?,?,?)
        `,
        [
          Number(job.id),
          job.title,
          job.type,
          job.description,
          job.location,
          job.salary,
          1, // Every default job belongs to Employer 1
        ]
      );
    });
  }

  return db;
}

// =======================================
// DATABASE
// =======================================

export function getDatabase() {
  return db;
}

// =======================================
// JOBS
// =======================================

export function getAllJobs() {
  const result = db.exec("SELECT * FROM jobs");

  if (result.length === 0) return [];

  return result[0].values.map((row) => ({
    id: row[0],
    title: row[1],
    type: row[2],
    description: row[3],
    location: row[4],
    salary: row[5],
    employerid: row[6],
  }));
}

export function getJobById(id) {
  const result = db.exec(
    `SELECT * FROM jobs WHERE id=${Number(id)}`
  );

  if (result.length === 0) return null;

  const row = result[0].values[0];

  return {
    id: row[0],
    title: row[1],
    type: row[2],
    description: row[3],
    location: row[4],
    salary: row[5],
    employerid: row[6],
  };
}

export function addJob(job, employerid) {
  db.run(
    `
    INSERT INTO jobs
    (
      title,
      type,
      description,
      location,
      salary,
      employerid
    )
    VALUES (?,?,?,?,?,?)
    `,
    [
      job.title,
      job.type,
      job.description,
      job.location,
      job.salary,
      Number(employerid),
    ]
  );
}

export function deleteJob(id) {
  db.run(
    `DELETE FROM jobs WHERE id=?`,
    [Number(id)]
  );
}

export function updateJob(job) {
  db.run(
    `
    UPDATE jobs
    SET
      title=?,
      type=?,
      description=?,
      location=?,
      salary=?
    WHERE id=?
    `,
    [
      job.title,
      job.type,
      job.description,
      job.location,
      job.salary,
      Number(job.id),
    ]
  );
}

export function getJobsByEmployer(employerid) {
  const result = db.exec(
    `SELECT * FROM jobs WHERE employerid=${Number(employerid)}`
  );

  if (result.length === 0) return [];

  return result[0].values.map((row) => ({
    id: row[0],
    title: row[1],
    type: row[2],
    description: row[3],
    location: row[4],
    salary: row[5],
    employerid: row[6],
  }));
}

// =======================================
// EMPLOYERS
// =======================================

export function loginEmployer(email, password) {
  const result = db.exec(
    `
    SELECT *
    FROM employers
    WHERE emailid='${email}'
    AND password='${password}'
    `
  );

  if (result.length === 0) return null;

  const row = result[0].values[0];

  return {
    employerid: row[0],
    emailid: row[1],
    password: row[2],
  };
}

// =======================================
// APPLICATIONS
// =======================================

export function addApplication(application) {
  db.run(
    `
    INSERT INTO applications
    (
      jobid,
      name,
      email,
      resumeLink
    )
    VALUES (?,?,?,?)
    `,
    [
      application.jobid,
      application.name,
      application.email,
      application.resumeLink,
    ]
  );
}

export function getApplicationsByJob(jobid) {
  const result = db.exec(
    `SELECT * FROM applications WHERE jobid=${Number(jobid)}`
  );

  if (result.length === 0) return [];

  return result[0].values.map((row) => ({
    applicationid: row[0],
    jobid: row[1],
    name: row[2],
    email: row[3],
    resumeLink: row[4],
  }));
}